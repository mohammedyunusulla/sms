from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from flask_jwt_extended import JWTManager
import os
import logging
from logging.handlers import RotatingFileHandler
from config import config

# Initialize extensions
db = SQLAlchemy()
migrate = Migrate()
cors = CORS()
jwt = JWTManager()

def create_app(config_name=None):
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV') or 'default'
    
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    jwt.init_app(app)
    
    # Setup logging
    setup_logging(app)
    
    # Register blueprints
    from app.api import (
        auth_bp, user_bp, teacher_bp, student_bp, school_bp, class_bp, subject_bp, attendance_bp,
        parent_bp, roles_bp, user_roles_bp, timeTable_bp, studentParent_bp, fee_bp
    )
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(user_bp, url_prefix='/api/users')
    app.register_blueprint(teacher_bp, url_prefix='/api/teachers')
    app.register_blueprint(student_bp, url_prefix='/api/students')
    app.register_blueprint(parent_bp, url_prefix='/api/parents')
    app.register_blueprint(studentParent_bp, url_prefix='/api/studentParent')
    app.register_blueprint(school_bp, url_prefix='/api/school')
    app.register_blueprint(class_bp, url_prefix='/api/classes')
    app.register_blueprint(subject_bp, url_prefix='/api/subjects')
    app.register_blueprint(attendance_bp, url_prefix='/api/attendance')
    app.register_blueprint(timeTable_bp, url_prefix='/api/timeTable')
    app.register_blueprint(fee_bp, url_prefix='/api/fee')
    app.register_blueprint(roles_bp, url_prefix='/api/roles')
    app.register_blueprint(user_roles_bp, url_prefix='/api/user-roles')
    
    # JWT token handlers
    @jwt.token_in_blocklist_loader
    def check_if_token_revoked(jwt_header, jwt_payload):
        # You can implement token blacklisting here if needed
        return False
    
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return {'message': 'Token has expired'}, 401
    
    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return {'message': 'Invalid token'}, 401
    
    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return {'message': 'Authorization token is required'}, 401
    
    return app

def setup_logging(app):
    if not app.debug and not app.testing:
        if not os.path.exists('logs'):
            os.mkdir('logs')
        
        file_handler = RotatingFileHandler(
            app.config['LOG_FILE'], 
            maxBytes=10240000, 
            backupCount=10
        )
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
        ))
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        
        app.logger.setLevel(logging.INFO)
        app.logger.info('School Management System startup')