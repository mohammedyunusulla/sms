from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from app.services import AuthService
from app.decorators import log_actions, login_required

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
@log_actions('USER_LOGIN')
def login():
    """
    User login endpoint
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        
        identifier = data.get('identifier') # Could be username or emai
        password = data.get('password')
        
        if not identifier  or not password:
            return jsonify({'message': 'Username and password are required'}), 400
        
        # Authenticate user
        user = AuthService.authenticate_user(identifier, password)
        if not user:
            return jsonify({'message': 'Invalid credentials'}), 400
        
        # Create session and tokens
        session_data = AuthService.create_user_session(user)
        
        return jsonify({
            'message': 'Login successful',
            'access_token': session_data['access_token'],
            'refresh_token': session_data['refresh_token'],
            'user': session_data['user'],
            'session_id': session_data['session_id']
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Login failed: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST'])
@login_required()
@log_actions('USER_LOGOUT')
def logout():
    """
    User logout endpoint
    """
    try:
        user = request.current_user
        
        # Debug: Print all JWT claims
        claims = get_jwt()
        print("All JWT claims:", claims)
        print("JWT identity:", get_jwt_identity())
        
        session_token = claims.get('session_token')
        print("Session token from claims:", session_token)
        
        if not session_token:
            print("WARNING: No session_token found in JWT claims")
            # You might want to handle this case differently
        
        # Logout user
        result = AuthService.logout_user(user, session_token)
        print("Logout service result:", result)
        
        return jsonify({'message': 'Logout successful'}), 200
        
    except Exception as e:
        print("Logout error:", str(e))
        import traceback
        traceback.print_exc()
        return jsonify({'message': f'Logout failed: {str(e)}'}), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
@log_actions('TOKEN_REFRESH')
def refresh():
    """
    Refresh access token
    """
    try:
        current_user_id = get_jwt_identity()
        
        # Create new access token
        token_data = AuthService.refresh_token(current_user_id)
        if not token_data:
            return jsonify({'message': 'Invalid refresh token'}), 401
        
        return jsonify({
            'message': 'Token refreshed successfully',
            'access_token': token_data['access_token'],
            'user': token_data['user']
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Token refresh failed: {str(e)}'}), 500

@auth_bp.route('/me', methods=['GET'])
@login_required()
def get_current_user():
    """
    Get current user information
    """
    try:
        user = request.current_user
        return jsonify({
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get user info: {str(e)}'}), 500

@auth_bp.route('/change-password', methods=['POST'])
@login_required()
@log_actions('PASSWORD_CHANGE')
def change_password():
    """
    Change user password
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        
        if not old_password or not new_password:
            return jsonify({'message': 'Old password and new password are required'}), 400
        
        user = request.current_user
        
        # Change password using service
        from app.services import UserService
        UserService.change_password(user.id, old_password, new_password)
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Password change failed: {str(e)}'}), 500