from flask import Blueprint, request, jsonify
from app.services.teacher_service import TeacherService
from app.decorators import log_actions, login_required
from app.models.main.User import UserRole

teacher_bp = Blueprint('teachers', __name__)

@teacher_bp.route('/create/<skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('CREATE_TEACHER_USER')
def create_teacher(skid):
    """
    Create a new teacher
    Only super admin and school admin can create users
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        if not skid:
            raise ValueError("School ID (skid) is required")
        
        # Check for duplicate before creating
        duplicate_check = TeacherService.check_duplicate_user(data, skid)
        if duplicate_check:
            return jsonify({'message': duplicate_check}), 200
        
        user = TeacherService.create_teacher_user(data, skid)
        
        return jsonify({
            'message': 'User created successfully',
            'user': user,
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to create user: {str(e)}'}), 500
        
@teacher_bp.route('/list/<skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('GET_TEACHERS')
def get_teachers(skid):
    """
    Get list of teachers
    """
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        teachers = TeacherService.get_teachers(skid)

        return jsonify({
            'teachers': teachers,
            'status': 'success',
            'code': 200
        }), 200
   
    except Exception as e:
        return jsonify({'message': f'Failed to get teachers: {str(e)}'}), 500

@teacher_bp.route('/<int:teacher_id>/subjects/<skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_teacher_subjects(teacher_id, skid):
    try:
        subject_ids = TeacherService.get_subject_ids_by_teacher(teacher_id, skid)
        return jsonify({
            "subject_ids": subject_ids,
            'status': 'success',
            'code': 200
        }), 200
    except Exception as e:
        return jsonify(message=str(e))
