from .auth import auth_bp
from .user import user_bp
from .teacher import teacher_bp
from .student import student_bp
from .school import school_bp
from .classes import class_bp
from .subject import subject_bp
from .roles import roles_bp
from .userRoles import user_roles_bp
from .attendance import attendance_bp
from .parent import parent_bp
from .timeTable import timeTable_bp
from .studentParent import studentParent_bp
from .fee import fee_bp

__all__ = ['auth_bp', 'user_bp', 'teacher_bp', 'student_bp', 
            'school_bp', 'class_bp', 'subject_bp', 'roles_bp',
            'user_roles_bp', 'attendance_bp', 'parent_bp', 'timeTable_bp', 'studentParent_bp', 'fee_bp'
        ]