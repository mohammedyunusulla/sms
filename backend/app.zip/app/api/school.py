from flask import Blueprint, request, jsonify
from app.decorators.auth import login_required
from app.decorators.logging import log_actions
from app.services.school_service import SchoolService
from app.models.main.User import UserRole
from app.models.main.School import School
import logging

logger = logging.getLogger(__name__)

school_bp = Blueprint('school', __name__)

@school_bp.route('/create', methods=['POST'])
@login_required(['SUPER_ADMIN'])
@log_actions('CREATE_SCHOOL')
def create_school():
    """Create a new school with database and initialize using models"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        
        # Check if school with same code exists
        existing_school = School.query.filter_by(code=data.get('code')).first()
        if existing_school:
            return jsonify({
                'message': f"School with code '{data['code']}' already exists.",
                'status': 'error',
                'code': 409
            }), 200
        
        # Create school
        result = SchoolService.create_school(data)
        
        if result['success']:
            return jsonify({
                'message': result['message'],
                'school': result['data'],
                'status': 'success',
                'code': 200
            }), 200
        else:
            return jsonify({'message': result['message']}), 400
            
    except Exception as e:
        logger.error(f"Error creating school: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500

@school_bp.route('/update/<int:school_id>', methods=['PUT'])
@login_required(['SUPER_ADMIN'])
@log_actions('UPDATE_SCHOOL')
def update_school(school_id):
    """Update school"""
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
            
        result = SchoolService.update_school(school_id, data)
        
        if result['success']:
            return jsonify({
                'message': result['message'],
                'school': result['data'],
                'status': 'success',
                'code': 200
            }), 200
        else:
            status_code = 404 if 'not found' in result['message'].lower() else 400
            return jsonify({'message': result['message']}), status_code
            
    except Exception as e:
        logger.error(f"Error updating school {school_id}: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500

@school_bp.route('/list', methods=['GET'])
@login_required(['SUPER_ADMIN'])
@log_actions('GET_SCHOOLS')
def get_schools():
    """Get list of schools with pagination"""
    try:
        # Get query parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        search = request.args.get('search', '')
        plan = request.args.get('plan', '')
        
        # Validate per_page
        if per_page > 100:
            per_page = 100
        
        result = SchoolService.get_schools(page, per_page, search, plan)
        
        if result['success']:
            return jsonify({
                'message': 'Schools retrieved successfully',
                'data': result['data'],
                'status': 'success',
                'code': 200
            }), 200
        else:
            return jsonify({'message': result['message']}), 400
        
    except Exception as e:
        logger.error(f"Error getting schools: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500

@school_bp.route('/<int:school_id>', methods=['GET'])
@login_required(['SUPER_ADMIN'])
@log_actions('GET_SCHOOL')
def get_school(school_id):
    """Get school by ID"""
    try:
        result = SchoolService.get_school_by_id(school_id)
        
        if result['success']:
            return jsonify({
                'message': 'School retrieved successfully',
                'school': result['data']
            }), 200
        else:
            return jsonify({'message': result['message']}), 404
            
    except Exception as e:
        logger.error(f"Error getting school {school_id}: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500

@school_bp.route('/delete/<int:school_id>', methods=['DELETE'])
@login_required(['SUPER_ADMIN'])
@log_actions('DELETE_SCHOOL')
def delete_school(school_id):
    """Soft delete school"""
    try:
        result = SchoolService.delete_school(school_id)
        
        if result['success']:
            return jsonify({
                'message': result['message'],
                'status': 'success',
                'code': 200
            }), 200
        else:
            return jsonify({'message': result['message']}), 404
            
    except Exception as e:
        logger.error(f"Error deleting school {school_id}: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500

@school_bp.route('/<int:school_id>/users', methods=['GET'])
@login_required(['SUPER_ADMIN'])
@log_actions('GET_SCHOOL_USERS')
def get_school_users(school_id):
    """Get users for a specific school"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        role = request.args.get('role', '')
        
        if per_page > 100:
            per_page = 100
        
        result = SchoolService.get_school_users(school_id, page, per_page, role)
        
        if result['success']:
            return jsonify({
                'message': 'School users retrieved successfully',
                'data': result['data']
            }), 200
        else:
            return jsonify({'message': result['message']}), 404
            
    except Exception as e:
        logger.error(f"Error getting users for school {school_id}: {str(e)}")
        return jsonify({'message': 'Internal server error'}), 500