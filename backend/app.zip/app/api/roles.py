from flask import Blueprint, request, jsonify
from app.services.roles_service import RolesService
from app.decorators import login_required

roles_bp = Blueprint('roles', __name__)

# 1. CREATE ROLE
@roles_bp.route('/create/role/<skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def create_role(skid):
    try:
        data = request.get_json()
        if not skid:
            raise ValueError("School ID (skid) is required")
        
        role = RolesService.create_role(data, skid)
        return jsonify({'message': 'Role created', 'data': role, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 2. GET ALL ROLES
@roles_bp.route('/list/<skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_all_roles(skid):
    try:
        rolesList = RolesService.get_all_roles(skid)
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        return jsonify({'data': rolesList, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 3. GET SINGLE ROLE BY ID
@roles_bp.route('/role/<skid>/<int:role_id>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_role_by_id(skid, role_id):
    try:
        role = RolesService.get_role_by_id(skid, role_id)
        if not skid:
            raise ValueError("School ID (skid) is required")
        
        return jsonify({'data': role, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 4. UPDATE ROLE
@roles_bp.route('/update/role/<skid>/<int:role_id>', methods=['PUT'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def update_role(skid, role_id):
    try:
        data = request.get_json()
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        updated_role = RolesService.update_role(role_id, data, skid)
        return jsonify({'message': 'Role updated', 'data': updated_role, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 5. ASSIGN PERMISSIONS TO ROLE
@roles_bp.route('/addPermissionsToRole/<skid>/<int:role_id>', methods=['PUT'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def assign_permissions(skid, role_id):
    try:
        data = request.get_json()
        permissions = data.get('permissions', [])
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        updated = RolesService.assign_permissions(skid, role_id, permissions)
        return jsonify({'message': 'Permissions updated', 'data': updated, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 6. TOGGLE ACTIVE/INACTIVE
@roles_bp.route('/toggleRole/<skid>/<int:role_id>', methods=['PATCH'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def toggle_role_status(skid, role_id):
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        updated = RolesService.toggle_role_status(role_id, skid)
        return jsonify({'message': 'Role status updated', 'data': updated, 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500


# 7. DELETE ROLE
@roles_bp.route('/delete/role/<skid>/<int:role_id>', methods=['DELETE'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def delete_role(skid, role_id):
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")
        
        RolesService.delete_role(role_id, skid)
        return jsonify({'message': 'Role deleted', 'status': 'success', 'code':200}), 200
    except Exception as e:
        return jsonify({'message': str(e), 'status': 'error'}), 500
