from flask import Blueprint, request, jsonify
from app.services import UserService
from app.decorators import log_actions, login_required, super_admin_required, school_admin_required, same_school_required
from app.models.main.User import UserRole

user_bp = Blueprint('users', __name__)

@user_bp.route('/create', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('CREATE_USER')
def create_school_admin():
    """
    Create a new school sadmin
    Only super admin
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        
        user = UserService.create_school_admin(data)
        
        return jsonify({
            'message': 'User created successfully',
            'user': user.to_dict(),
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to create user: {str(e)}'}), 500

@user_bp.route('/update/<int:user_id>', methods=['PUT'])
@login_required(['super_admin', 'school_admin'])
@log_actions('UPDATE_USER')
def update_user(user_id):
    """
    Update user information
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        
        current_user = request.current_user
        
        # Get the user to be updated
        target_user = UserService.get_user_by_id(user_id, include_inactive=True)
        if not target_user:
            return jsonify({'message': 'User not found'}), 404
        
        # Validate permissions
        if current_user.role == UserRole.SCHOOL_ADMIN:
            # School admin can only update users from their own school
            if target_user.school_id != current_user.school_id:
                return jsonify({'message': 'Cannot update user from different school'}), 403
            
            # School admin cannot update super admin or other school admins
            if target_user.role in [UserRole.SUPER_ADMIN, UserRole.SCHOOL_ADMIN]:
                return jsonify({'message': 'Insufficient permissions to update this user'}), 403
            
            # School admin cannot assign super admin or school admin roles
            if data.get('role') in ['super_admin', 'school_admin']:
                return jsonify({'message': 'Insufficient permissions to assign this role'}), 403
            
            # Force school_id to current user's school if provided
            if 'school_id' in data:
                data['school_id'] = current_user.school_id
        
        # Update user using service
        user = UserService.update_user(user_id, data)
        
        return jsonify({
            'message': 'User updated successfully',
            'user': user.to_dict()
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to update user: {str(e)}'}), 500

@user_bp.route('/<int:user_id>/deactivate', methods=['POST'])
@login_required(['super_admin', 'school_admin'])
@log_actions('DEACTIVATE_USER')
def deactivate_user(user_id):
    """
    Deactivate user (set status as Inactive)
    """
    try:
        current_user = request.current_user
        
        # Get the user to be deactivated
        target_user = UserService.get_user_by_id(user_id, include_inactive=True)
        if not target_user:
            return jsonify({'message': 'User not found'}), 404
        
        # Validate permissions
        if current_user.role == UserRole.SCHOOL_ADMIN:
            # School admin can only deactivate users from their own school
            if target_user.school_id != current_user.school_id:
                return jsonify({'message': 'Cannot deactivate user from different school'}), 403
            
            # School admin cannot deactivate super admin or other school admins
            if target_user.role in [UserRole.SUPER_ADMIN, UserRole.SCHOOL_ADMIN]:
                return jsonify({'message': 'Insufficient permissions to deactivate this user'}), 403
        
        # Prevent self-deactivation
        if current_user.id == user_id:
            return jsonify({'message': 'Cannot deactivate your own account'}), 400
        
        # Deactivate user using service
        user = UserService.deactivate_user(user_id)
        
        return jsonify({
            'message': 'User deactivated successfully',
            'user': user.to_dict()
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to deactivate user: {str(e)}'}), 500

@user_bp.route('/<int:user_id>/activate', methods=['POST'])
@login_required(['super_admin', 'school_admin'])
@log_actions('ACTIVATE_USER')
def activate_user(user_id):
    """
    Activate user (set status as Active)
    """
    try:
        current_user = request.current_user
        
        # Get the user to be activated
        target_user = UserService.get_user_by_id(user_id, include_inactive=True)
        if not target_user:
            return jsonify({'message': 'User not found'}), 404
        
        # Validate permissions
        if current_user.role == UserRole.SCHOOL_ADMIN:
            # School admin can only activate users from their own school
            if target_user.school_id != current_user.school_id:
                return jsonify({'message': 'Cannot activate user from different school'}), 403
            
            # School admin cannot activate super admin or other school admins
            if target_user.role in [UserRole.SUPER_ADMIN, UserRole.SCHOOL_ADMIN]:
                return jsonify({'message': 'Insufficient permissions to activate this user'}), 403
        
        # Activate user using service
        user = UserService.activate_user(user_id)
        
        return jsonify({
            'message': 'User activated successfully',
            'user': user.to_dict(),
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to activate user: {str(e)}'}), 500

@user_bp.route('/list/<skid>', methods=['GET'])
@login_required(['SCHOOL_ADMIN'])
@log_actions('GET_USERS')
def get_school_users(skid):
    """
    Get list of users in the specific school
    """
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")

        users = UserService.get_users_by_school(skid)
        
        return jsonify({
            'users': users,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get users: {str(e)}'}), 500

@user_bp.route('/schoolAdmin/<skid>/<int:user_id>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('GET_USER')
def get_user(skid, user_id):
    """
    Get specific user information
    """
    try:
        print("coming here----")
        current_user = request.current_user
        include_inactive = request.args.get('include_inactive', 'false').lower() == 'true'
        
        # Get user
        user = UserService.get_user_by_id(user_id, include_inactive)
        if not user:
            return jsonify({'message': 'User not found'}), 404
        
        # Validate permissions
        if current_user.role == UserRole.SCHOOL_ADMIN:
            # School admin can only view users from their own school
            if user.school_id != current_user.school_id:
                return jsonify({'message': 'Cannot view user from different school'}), 403
        
        return jsonify({
            'user': user.to_dict(),
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to get user: {str(e)}'}), 500

