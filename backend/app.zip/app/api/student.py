from flask import Blueprint, request, jsonify
from app.services.student_service import StudentService
from app.decorators import log_actions, login_required
from app.models.main.User import UserRole

student_bp = Blueprint('students', __name__)

@student_bp.route('/create/<skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('CREATE_TEACHER_USER')
def create_student(skid):
    """
    Create a new student
    Only super admin and school admin can create users
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        if not skid:
            return jsonify({'message': 'School ID is required'}), 400
        
        duplicate_check = StudentService.check_duplicate_user(data, skid)
        if duplicate_check:
            return jsonify({'message': duplicate_check}), 400
            
        student = StudentService.create_student_user(data, skid)
        
        return jsonify({
            'message': 'Student created successfully',
            'student': student,
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to create user: {str(e)}'}), 500


@student_bp.route('/bulk-create/<skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('BULK-CREATE-STUDENTS')
def bulk_create_students(skid):
    """Create multiple students in bulk"""
    try:
        data = request.get_json()
        
        if not data or 'students' not in data:
            return jsonify({'message': 'No student data provided'}), 400
            
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        result = StudentService.bulk_create_students(
            data['students'], 
            skid, 
            data.get('default_password', 'Admin@123')
        )
        
        return jsonify({
            'message': 'Bulk student creation completed',
            'data': result,
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to create students: {str(e)}'}), 500


@student_bp.route('/update/<skid>/<student_id>', methods=['PUT'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('UPDATE-STUDENT')
def update_student(skid, student_id):
    """Update existing student"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'message': 'No data provided'}), 400
            
        result = StudentService.update_student(student_id, skid, data)
        
        return jsonify({
            'message': 'Student updated successfully',
            'data': result,
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({'message': str(e)}), 400
    except Exception as e:
        return jsonify({'message': f'Failed to update student: {str(e)}'}), 500


@student_bp.route('/list/<skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('GET_STUDENTS')
def get_students(skid):
    """
    Get list of students
    """
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        students = StudentService.get_students(skid)

        return jsonify({
            'students': students,
            'status': 'success',
            'code': 200
        }), 200
   
    except Exception as e:
        return jsonify({'message': f'Failed to get students: {str(e)}'}), 500

# Fetch student list for the section based on the sectionId
@student_bp.route('/list/inSection/<skid>/<int:section_id>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER'])
def get_students_for_section(skid, section_id):
    """
    Get all students for a specific class-section
    """
    try:
        students = StudentService.get_students_for_section(section_id, skid)
        
        return jsonify({
            'message': 'students retrieved successfully',
            'data': students,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to retrieve students: {str(e)}', 'status': 'error', 'code': 500}), 500

@student_bp.route('/get-by-id/<skid>/<int:id>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('GET_STUDENTS')
def get_student_by_id(skid, id):
    """
    Get list of students
    """
    try:
        if not skid:
            raise ValueError("School ID (skid) is required")
            
        student = StudentService.get_student_by_id(skid, id)

        return jsonify({
            'student': student,
            'status': 'success',
            'code': 200
        }), 200
   
    except Exception as e:
        return jsonify({'message': f'Failed to get students: {str(e)}'}), 500