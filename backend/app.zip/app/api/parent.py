from flask import Blueprint, request, jsonify
from app.services.parent_service import ParentService
from app.decorators import log_actions, login_required

parent_bp = Blueprint('parents', __name__)

@parent_bp.route('/create/details/<skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('CREATE_PARENT_USER')  
def create_parent(skid):
    """
    Create a new parent
    """
    try:
        print("coming here")
        data = request.get_json()
        
        if not data:
            return jsonify({'message': 'No data provided'}), 400
        if not skid:
            raise ValueError("School ID (skid) is required")
        
        user = ParentService.create_parent_user(data, skid)
        
        return jsonify({
            'message': 'Parent created successfully',
            'data': user,
            'status': 'success',
            'code': 200
        }), 200
        
    except ValueError as e:
        return jsonify({
            'message': str(e),
            'status': 'error',
            'code': 400
        }), 400
    except Exception as e:
        return jsonify({
            'message': f'Failed to create parent: {str(e)}',
            'status': 'error',
            'code': 500
        }), 500

@parent_bp.route('/list/<skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_parents(skid):
    """
    Get all parents for a school
    """
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        search = request.args.get('search', '')
        
        parents = ParentService.get_all_parents(skid, page, per_page, search)
        
        return jsonify({
            'parents': parents,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({'message': f'Failed to fetch parents: {str(e)}',}), 500

@parent_bp.route('/<int:parent_id>/<int:skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_parent_detail(parent_id, skid):
    """
    Get parent details
    """
    try:
        parent = ParentService.get_parent_by_id(parent_id, skid)
        
        return jsonify({
            'message': 'Parent details fetched successfully',
            'data': parent,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({
            'message': f'Failed to fetch parent: {str(e)}',
            'status': 'error',
            'code': 500
        }), 500

@parent_bp.route('/link-student/<int:skid>', methods=['POST'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
@log_actions('LINK_PARENT_STUDENT')
def link_parent_student(skid):
    """
    Link parent to student
    """
    try:
        data = request.get_json()
        
        student_user_id = data.get('student_user_id')
        parent_user_id = data.get('parent_user_id')
        relation_type = data.get('relation_type', 'Guardian')
        
        if not student_user_id or not parent_user_id:
            return jsonify({
                'message': 'student_user_id and parent_user_id are required',
                'status': 'error',
                'code': 400
            }), 400
        
        result = ParentService.link_student_to_parent(
            student_user_id, parent_user_id, relation_type, skid
        )
        
        return jsonify({
            'message': 'Parent linked to student successfully',
            'data': result,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({
            'message': f'Failed to link parent: {str(e)}',
            'status': 'error',
            'code': 500
        }), 500

@parent_bp.route('/student/<int:student_id>/parents/<int:skid>', methods=['GET'])
@login_required(['SUPER_ADMIN', 'SCHOOL_ADMIN'])
def get_student_parents(student_id, skid):
    """
    Get all parents for a student
    """
    try:
        parents = ParentService.get_student_parents(student_id, skid)
        
        return jsonify({
            'message': 'Student parents fetched successfully',
            'data': parents,
            'status': 'success',
            'code': 200
        }), 200
        
    except Exception as e:
        return jsonify({
            'message': f'Failed to fetch student parents: {str(e)}',
            'status': 'error',
            'code': 500
        }), 500
