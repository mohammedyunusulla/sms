from app.models.main.User import User, UserRole
from app.models.main.School import School
from app.models.tenant import Student, SchoolUsers, StudentEnrollment, Class, StudentParent, Parent
from app.models.tenant.Sections import Section
from app import db
from sqlalchemy.exc import IntegrityError
from flask import jsonify
from app.utils.db_manager import switch_to_school_db
from app.services.userRole_service import UserRolesService
from datetime import datetime, date

class StudentService:

    @staticmethod
    def create_student_user(data, skid):
        user = None  # Track user so we can delete if needed
        school_user_id = None # New variable to store the ID from the tenant DB
        try:
            # Create user in main DB
            user = User(
                username=data['username'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                phone=data.get('phone'),
                role=UserRole(data['role']),
                skid=skid,
                school_id=data.get('school_id')
            )
            user.set_password(data['password'])
            user.save()
    
            # Insert into tenant DB
            with switch_to_school_db(skid) as tenant_session:
                school_user = SchoolUsers(
                    username=data['username'],
                    email=data['email'],
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    phone=data.get('phone'),
                    gender=data.get('gender'),
                    date_of_birth=data.get('date_of_birth'),
                    role_id = data.get('role_id'),
                    skid=skid,
                    is_active=True
                )
                school_user.set_password(data['password'])
                tenant_session.add(school_user)
                tenant_session.flush()
                
                # Get the ID of the school user before the session closes
                school_user_id = school_user.id
    
                # Create student profile
                if user.role == UserRole.STUDENT:
                    student_profile = Student(
                        user_id=school_user_id,
                        student_id=data.get('student_id'),  # make sure this is not None!
                        admission_date=data.get('admission_date'),
                        class_id=data.get('class_id'),
                        section_id=data.get('section_id')
                    )
                    
                    tenant_session.add(student_profile)

                    # ✅ Create Student Enrollment record
                    enrollment = StudentEnrollment(
                        student_id=school_user_id,
                        class_id=data.get('class_id'),
                        section_id=data.get('section_id'),
                        enrollment_date = data.get('admission_date')
                    )
                    tenant_session.add(enrollment)
                else:
                    raise ValueError("Only teacher/student logic implemented. Add parent/staff if needed.")
    
                tenant_session.commit()
    
                # Update main user with school_user_id
            user.school_user_id = school_user_id
            db.session.commit()
            
            # Assign the role after creating the teacher on the basis of role_id
            role_data = {
                "user_id": school_user_id,
                "role_id": data.get("role_id"),
                "assigned_by": 1
            }
            UserRolesService.assign_role_to_user(role_data, skid)
    
            return user.to_dict()
    
        except Exception as e:
            db.session.rollback()
    
            # Rollback tenant session if open
            if 'tenant_session' in locals():
                tenant_session.rollback()
    
            # Delete user from main DB if already created
            if user and user.id:
                try:
                    db.session.delete(user)
                    db.session.commit()
                except Exception as delete_error:
                    db.session.rollback()
                    print(f"Failed to clean up user from main DB: {delete_error}")
    
            raise Exception(f"Failed to create school user: {str(e)}")
    
    @staticmethod
    def update_student(user_id, skid, data):
        """
        Update student information across main and tenant databases
        user_id: The school_user_id (ID from SchoolUsers table in tenant DB)
        skid: School identifier
        data: Dictionary containing fields to update
        """
        main_user = None
        tenant_session = None
        
        # Define fields that should never be updated
        PROTECTED_FIELDS = {'id', 'created_at', 'user_id'}
        
        try:
            # Step 1: Fetch the user from the main database using school_user_id
            main_user = db.session.query(User).filter_by(
                school_user_id=user_id, 
                skid=skid
            ).first()
            if not main_user:
                raise ValueError("User not found in main database.")
    
            school_user_id = main_user.school_user_id
            
            # Step 2: Validate uniqueness for email if it's being changed
            if 'email' in data and data['email'] != main_user.email:
                # Check in main database (exclude current user)
                existing_main_user = db.session.query(User).filter(
                    User.email == data['email'],
                    User.school_user_id != school_user_id
                ).first()
                if existing_main_user:
                    raise ValueError("Email already exists in the system.")
                
                # Check in tenant database
                with switch_to_school_db(skid) as temp_session:
                    existing_tenant_user = temp_session.query(SchoolUsers).filter(
                        SchoolUsers.email == data['email'],
                        SchoolUsers.id != school_user_id
                    ).first()
                    if existing_tenant_user:
                        raise ValueError("Email already exists in the school.")
            
            # Step 3: Validate uniqueness for username if it's being changed
            if 'username' in data and data['username'] != main_user.username:
                # Check in main database (exclude current user)
                existing_main_user = db.session.query(User).filter(
                    User.username == data['username'],
                    User.school_user_id != school_user_id
                ).first()
                if existing_main_user:
                    raise ValueError("Username already exists in the system.")
                
                # Check in tenant database
                with switch_to_school_db(skid) as temp_session:
                    existing_tenant_user = temp_session.query(SchoolUsers).filter(
                        SchoolUsers.username == data['username'],
                        SchoolUsers.id != school_user_id
                    ).first()
                    if existing_tenant_user:
                        raise ValueError("Username already exists in the school.")
            
            # Step 4: Update the user in the main database
            for key, value in data.items():
                # Skip protected fields, password (handled separately), and fields not in model
                if key in PROTECTED_FIELDS or key == 'password' or not hasattr(main_user, key):
                    continue
                setattr(main_user, key, value)
            
            # If a new password is provided, set it
            if 'password' in data and data['password']:
                main_user.set_password(data['password'])
            
            db.session.commit()
            
            # Step 5: Update the user in the tenant database
            with switch_to_school_db(skid) as tenant_session:
                # Find the SchoolUsers entry
                school_user = tenant_session.query(SchoolUsers).filter_by(
                    id=school_user_id, 
                    skid=skid
                ).first()
                if not school_user:
                    raise ValueError("User not found in tenant database.")
    
                # Update SchoolUsers's fields
                for key, value in data.items():
                    # Skip protected fields and password
                    if key in PROTECTED_FIELDS or key == 'password':
                        continue
                        
                    if hasattr(school_user, key):
                        setattr(school_user, key, value)
                
                # If a new password is provided, set it
                if 'password' in data and data['password']:
                    school_user.set_password(data['password'])
    
                # Find the Student profile and update its fields
                student_profile = tenant_session.query(Student).filter_by(
                    user_id=school_user_id
                ).first()
                if not student_profile:
                    raise ValueError("Student profile not found in tenant database.")
    
                # Update student-specific fields
                for key, value in data.items():
                    # Skip protected fields
                    if key in PROTECTED_FIELDS:
                        continue
                        
                    if hasattr(student_profile, key):
                        setattr(student_profile, key, value)
    
                tenant_session.commit()
                
            return main_user.to_dict()
    
        except Exception as e:
            # Central rollback for the update function
            db.session.rollback()
            if tenant_session is not None:
                tenant_session.rollback()
            raise Exception(f"Failed to update user: {str(e)}")

    
    @staticmethod
    def check_duplicate_user(data, skid):
        """
        Check if user already exists in both main DB and tenant DB
        Returns error message if duplicate found, None if no duplicates
        """
        try:
            # Check main DB first
            existing_main_user = User.query.filter(
                (User.username == data['username']) | (User.email == data['email'])
            ).filter(User.skid == skid).first()
            
            if existing_main_user:
                return "Student with this username or email already exists"
            
            # Check tenant DB
            with switch_to_school_db(skid) as tenant_session:
                existing_tenant_user = tenant_session.query(SchoolUsers).filter(
                    (SchoolUsers.username == data['username']) | (SchoolUsers.email == data['email'])
                ).first()
                
                if existing_tenant_user:
                    return "Student with this username or email already exists"
            
            # Check if student ID already exists (if provided)
            if data.get('student_id'):
                with switch_to_school_db(skid) as tenant_session:
                    existing_student = tenant_session.query(Student).filter(
                        Student.student_id == data['student_id']
                    ).first()
                    if existing_student:
                        return "Student ID already exists"
            return None
            
        except Exception as e:
            return f"Error checking for duplicates: {str(e)}"
    
    @staticmethod
    def get_students(skid):
        try:
            with switch_to_school_db(skid) as tenant_session:
                Students = (
                    tenant_session.query(SchoolUsers, Student, Class, Section)
                    .join(Student, SchoolUsers.id == Student.user_id)
                    .outerjoin(Class, Student.class_id == Class.id)
                    .outerjoin(Section, Student.section_id == Section.id)
                    .all()
                )
    
                student_list = []
                for school_user, student, class_, section in Students:
                    # Convert base SchoolUser data to dict
                    user_dict = school_user.to_dict()
    
                    # Attach student profile info (like your existing "profile" key)
                    user_dict["profile"] = student.to_dict() if student else None
    
                    # Attach nested class and section objects (like "role" or "profile")
                    user_dict["class"] = class_.to_dict() if class_ else None
                    user_dict["section"] = section.to_dict() if section else None
    
                    student_list.append(user_dict)
    
                return student_list
    
        except Exception as e:
            raise Exception(f"Failed to get Students: {str(e)}")

    @staticmethod
    def get_student_by_id(skid, id):
        try:
            with switch_to_school_db(skid) as tenant_session:
                student = (
                    tenant_session.query(SchoolUsers, Student, Class, Section)
                    .join(Student, SchoolUsers.id == Student.user_id)
                    .outerjoin(Class, Student.class_id == Class.id)
                    .outerjoin(Section, Student.section_id == Section.id)
                    .filter(Student.user_id == id)
                    .first()
                )

                if not student:
                    return None

                school_user, student, class_, section = student

                # Convert base SchoolUser data to dict
                user_dict = school_user.to_dict()

                # Attach student profile info (like your existing "profile" key)
                user_dict["profile"] = student.to_dict() if student else None

                # Attach nested class and section objects (like "role" or "profile")
                user_dict["class"] = class_.to_dict() if class_ else None
                user_dict["section"] = section.to_dict() if section else None
                
                # Fetch parent information
                parent_result = (
                    tenant_session.query(StudentParent, Parent, SchoolUsers)
                    .join(Parent, StudentParent.parent_user_id == Parent.user_id)
                    .join(SchoolUsers, Parent.user_id == SchoolUsers.id)
                    .filter(StudentParent.student_user_id == id)
                    .first()
                )
                
                parent_data = None
                if parent_result:
                    try:
                        link, parent_obj, parent_user = parent_result
                        parent_data = {
                            'id': parent_obj.user_id,
                            'relation_type': link.relation_type,
                            'father_full_name': parent_obj.father_full_name,
                            'mother_full_name': parent_obj.mother_full_name,
                            'father_phone': parent_obj.father_phone,
                            'mother_phone': parent_obj.mother_phone,
                            'email': parent_user.email,
                            'phone': parent_user.phone,
                            'address': parent_obj.address,
                            'city': parent_obj.city,
                            'state': parent_obj.state,
                            'postal_code': parent_obj.postal_code,
                            'father_occupation': parent_obj.father_occupation,
                            'father_qualification': parent_obj.father_qualification,
                            'mother_occupation': parent_obj.mother_occupation,
                            'mother_qualification': parent_obj.mother_qualification
                        }
                    except (ValueError, TypeError, AttributeError) as e:
                        print(f"Error unpacking parent data: {e}")
                        parent_data = None
                
                # ✅ Set parent data outside the if block
                user_dict["parent"] = parent_data


                return user_dict

        except Exception as e:
            raise Exception(f"Failed to get Student by ID: {str(e)}")

    
    @staticmethod
    def get_students_for_section(section_id, skid):
        """
        Get all students for a specific section
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                # Get enrollments for the section
                enrollments = tenant_session.query(StudentEnrollment).filter_by(section_id=section_id).all()
                students = []
    
                for enrollment in enrollments:
                    result = tenant_session.query(SchoolUsers, Student).join(
                        Student, SchoolUsers.id == Student.user_id
                    ).filter(
                        SchoolUsers.id == enrollment.student_id
                    ).first()
                
                    if result:
                        user, student_profile = result
                        students.append({ 
                            "id": user.id,
                            "full_name": f"{user.first_name} {user.last_name}",
                            "email": user.email,
                            "phone": user.phone,
                            "dob": user.date_of_birth,
                            "profile": {
                                "roll_no": student_profile.roll_no,
                                "admission_date": student_profile.admission_date,
                                "class_id": student_profile.class_id,
                                "section_id": student_profile.section_id
                            } if student_profile else None
                        })
        
                return students
    
        except Exception as e:
            raise Exception(f"Failed to get Students: {str(e)}")

    @staticmethod
    def bulk_create_students(students_data, skid, default_password='Admin@123'):
        """
        Create multiple students in bulk
        """
        try:
            # Get school information
            school = School.query.filter_by(skid=skid).first()
            if not school:
                raise ValueError("School not found")
    
            # Initialize counters
            successful = 0
            failed = 0
            errors = []
            created_students = []
    
            # Get or create classes and sections mapping
            with switch_to_school_db(skid) as tenant_session:
                # Get existing classes and sections
                from app.models.tenant.Class import Class
                from app.models.tenant.Sections import Section
                
                classes = tenant_session.query(Class).all()
                sections = tenant_session.query(Section).all()
                
                # Create mapping for quick lookup
                class_map = {cls.class_name: cls.id for cls in classes}
                section_map = {(sec.section_name, sec.class_id): sec.id for sec in sections}
    
            for idx, student_data in enumerate(students_data):
                user = None  # Track user so we can delete if needed
                school_user_id = None  # Track tenant DB user ID
                
                try:
                    # Validate required fields
                    required_fields = ['first_name', 'last_name', 'email', 'phone', 'gender', 'class_name', 'section_name']
                    missing_fields = [field for field in required_fields if not student_data.get(field)]
                    
                    if missing_fields:
                        raise ValueError(f"Missing required fields: {', '.join(missing_fields)}")
    
                    # Get class and section IDs
                    class_name = student_data['class_name']
                    section_name = student_data['section_name']
                    
                    class_id = class_map.get(class_name)
                    if not class_id:
                        raise ValueError(f"Class '{class_name}' not found")
                    
                    section_id = section_map.get((section_name, class_id))
                    if not section_id:
                        raise ValueError(f"Section '{section_name}' not found in class '{class_name}'")
    
                    # Check if user already exists in main DB
                    existing_user = User.query.filter(
                        (User.email == student_data['email']) | 
                        (User.phone == student_data['phone'])
                    ).first()
                    
                    if existing_user:
                        raise ValueError(f"Student with email '{student_data['email']}' or phone '{student_data['phone']}' already exists")
    
                    # Create user in main DB (following create_student_user pattern)
                    user_data = {
                        'username': student_data.get('username', student_data['email']),
                        'email': student_data['email'],
                        'first_name': student_data['first_name'],
                        'last_name': student_data['last_name'],
                        'phone': student_data.get('phone'),
                        'role': UserRole.STUDENT,  # Use enum like in create_student_user
                        'skid': skid,
                        'school_id': school.id
                    }
                    
                    user = User(**user_data)
                    user.set_password(student_data.get('password', default_password))
                    user.save()
    
                    # Insert into tenant DB (following create_student_user pattern)
                    with switch_to_school_db(skid) as tenant_session:
                        from app.models.tenant import SchoolUsers, Student, StudentEnrollment
                        
                        # Check if a user with the same username or email already exists in the tenant DB
                        existing_user = tenant_session.query(SchoolUsers).filter(
                            (SchoolUsers.username == user_data['username']) | (SchoolUsers.email == student_data['email'])
                        ).first()
                        if existing_user:
                            # If an existing user is found, roll back the main DB user creation and raise an error.
                            db.session.rollback()
                            raise ValueError("User with this username or email already exists in this school.")
                        
                        # Create school user in tenant DB
                        school_user = SchoolUsers(
                            username=user_data['username'],
                            email=student_data['email'],
                            first_name=student_data['first_name'],
                            last_name=student_data['last_name'],
                            phone=student_data.get('phone'),
                            date_of_birth=datetime.strptime(student_data['date_of_birth'], '%Y-%m-%d').date() if student_data.get('date_of_birth') else None,
                            role_id=student_data.get('role_id', 4),  # Default student role
                            skid=skid,
                            is_active=True
                        )
                        school_user.set_password(student_data.get('password', default_password))
                        tenant_session.add(school_user)
                        tenant_session.flush()
                        
                        # Get the ID of the school user before the session closes
                        school_user_id = school_user.id
    
                        # Create student profile (following create_student_user pattern)
                        student_profile = Student(
                            user_id=school_user_id,
                            student_id=student_data.get('student_id'),
                            admission_date=datetime.strptime(student_data['admission_date'], '%Y-%m-%d').date() if student_data.get('admission_date') else datetime.utcnow().date(),
                            class_id=class_id,
                            section_id=section_id
                        )
                        tenant_session.add(student_profile)
    
                        # Create Student Enrollment record (following create_student_user pattern)
                        enrollment = StudentEnrollment(
                            student_id=school_user_id,
                            class_id=class_id,
                            section_id=section_id,
                            enrollment_date=datetime.strptime(student_data['admission_date'], '%Y-%m-%d').date() if student_data.get('admission_date') else datetime.utcnow().date()
                        )
                        tenant_session.add(enrollment)
    
                        tenant_session.commit()
    
                    # Update main user with school_user_id (following create_student_user pattern)
                    user.school_user_id = school_user_id
                    db.session.commit()
                    
                    # Assign the role after creating the student (following create_student_user pattern)
                    role_data = {
                        "user_id": school_user_id,
                        "role_id": student_data.get("role_id", 4),  # Default student role
                        "assigned_by": 1
                    }
                    UserRolesService.assign_role_to_user(role_data, skid)
    
                    successful += 1
                    created_students.append({
                        'row': idx + 1,
                        'name': f"{student_data['first_name']} {student_data['last_name']}",
                        'email': student_data['email'],
                        'student_id': student_data.get('student_id'),
                        'status': 'success'
                    })
    
                except Exception as e:
                    db.session.rollback()
                    
                    # Rollback tenant session if open
                    if 'tenant_session' in locals():
                        tenant_session.rollback()
    
                    # Delete user from main DB if already created
                    if user and user.id:
                        try:
                            db.session.delete(user)
                            db.session.commit()
                        except Exception as delete_error:
                            db.session.rollback()
                            print(f"Failed to clean up user from main DB: {delete_error}")
    
                    failed += 1
                    error_msg = str(e)
                    errors.append({
                        'row': idx + 1,
                        'name': f"{student_data.get('first_name', '')} {student_data.get('last_name', '')}",
                        'email': student_data.get('email', ''),
                        'error': error_msg,
                        'status': 'failed'
                    })
                    continue
    
            return {
                'total': len(students_data),
                'successful': successful,
                'failed': failed,
                'errors': errors,
                'created_students': created_students,
                'summary': {
                    'success_rate': round((successful / len(students_data)) * 100, 2) if len(students_data) > 0 else 0,
                    'total_processed': len(students_data)
                }
            }
    
        except Exception as e:
            db.session.rollback()
            raise e