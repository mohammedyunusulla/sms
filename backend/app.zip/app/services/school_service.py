from app.models.main.School import School, SchoolPlan
from app.models.main.User import User, UserRole
from app import db
from app.services.user_service import UserService
from app.utils.db_manager import DatabaseManager
from app.utils.db_name_generator import DatabaseNameGenerator
import re
import logging
from sqlalchemy import and_, or_

logger = logging.getLogger(__name__)

class SchoolService:
    
    @staticmethod
    def create_school(data):
        """Create a new school"""
        try:
             # Generate unique database name
            db_name = DatabaseNameGenerator.generate_db_name(data)
            print("db_name----------", db_name)
            # Validate plan if provided
            plan = data.get('plan', 'BASIC').upper()
            if plan not in [p.value for p in SchoolPlan]:
                return {
                    'success': False,
                    'message': f'Invalid plan. Must be one of: {", ".join([p.value for p in SchoolPlan])}'
                }
            
            
            # Step 1: Create database for school
            try:
                created_db_name  = DatabaseManager.create_school_database(db_name)
                print("created_db_name----------", created_db_name)
            except Exception as db_error:
                logger.error(f"Error creating school database: {str(db_error)}")
                return {
                    'success': False,
                    'message': 'Failed to create dedicated database for school'
                }
            
            # Step 2: Initialize database schema
            try:
                DatabaseManager.initialize_school_schema(created_db_name)
            except Exception as schema_error:
                logger.error(f"Error initializing school schema: {str(schema_error)}")
                # Cleanup: Drop the created database
                DatabaseManager.drop_school_database(created_db_name)
                return {
                    'success': False,
                    'message': 'Failed to initialize database schema'
                }

            # Step 3: Create school entry in the main DB
            school = School(
                name=data['name'].strip(),
                code=data['code'].strip(),
                address=data.get('address', '').strip(),
                phone=data.get('phone', '').strip(),
                email=data.get('email', '').strip(),
                city=data.get('city', '').strip(),
                state=data.get('state', '').strip(),
                country=data.get('country', '').strip(),
                website=data.get('website', '').strip(),
                plan=SchoolPlan(plan),
                skid=created_db_name.replace("skool_", "").strip()
            )
            
            school.save()
            logger.info(f"School created successfully: {school.name} ({school.code})")
            
            return {
                'success': True,
                'message': 'School created successfully',
                'data': school.to_dict()
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error creating school: {str(e)}")
            DatabaseManager.drop_school_database(created_db_name)
            return {
                'success': False,
                'message': 'Failed to create school'
            }
    
    @staticmethod
    def get_schools(page=1, per_page=10, search='', plan=''):
        """Get paginated list of schools with optional search and filter"""
        try:
            query = School.query.filter(School.is_active == True)
            
            # Apply search filter
            if search:
                search_filter = or_(
                    School.name.ilike(f'%{search}%'),
                    School.code.ilike(f'%{search}%'),
                    School.email.ilike(f'%{search}%')
                )
                query = query.filter(search_filter)
            
            # Apply plan filter
            if plan and plan in [p.value for p in SchoolPlan]:
                query = query.filter(School.plan == SchoolPlan(plan))
            
            # Get paginated results
            pagination = query.order_by(School.created_at.desc()).paginate(
                page=page, per_page=per_page, error_out=False
            )
            
            schools = [school.to_dict() for school in pagination.items]
            
            return {
                'success': True,
                'data': {
                    'schools': schools,
                    'pagination': {
                        'page': pagination.page,
                        'pages': pagination.pages,
                        'per_page': pagination.per_page,
                        'total': pagination.total,
                        'has_next': pagination.has_next,
                        'has_prev': pagination.has_prev
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting schools: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to retrieve schools'
            }
    
    @staticmethod
    def get_school_by_id(school_id):
        """Get school by ID"""
        try:
            school = School.query.filter(
                and_(School.id == school_id, School.is_active == True)
            ).first()
            
            if not school:
                return {
                    'success': False,
                    'message': 'School not found'
                }
            
            # Include user count in the response
            school_data = school.to_dict()
            school_data['user_count'] = User.query.filter(
                and_(User.school_id == school_id, User.is_active == True)
            ).count()
            
            return {
                'success': True,
                'data': school_data
            }
            
        except Exception as e:
            logger.error(f"Error getting school {school_id}: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to retrieve school'
            }
    
    @staticmethod
    def update_school(school_id, data):
        """Update school information"""
        try:
            school = School.query.filter(
                and_(School.id == school_id, School.is_active == True)
            ).first()
            
            if not school:
                return {
                    'success': False,
                    'message': 'School not found'
                }
            
            # Update fields if provided
            if 'name' in data:
                school.name = data['name'].strip()
            
            if 'code' in data:
                school.code = data['code'].strip()
            
            if 'address' in data:
                school.address = data['address'].strip()
            
            if 'city' in data:
                school.city = data['city'].strip()
            
            if 'state' in data:
                school.state = data['state'].strip()
            
            if 'country' in data:
                school.country = data['country'].strip()
            
            if 'phone' in data:
                school.phone = data['phone'].strip()
            
            if 'email' in data:
                school.email = data['email'].strip()
            
            if 'website' in data:
                school.website = data['website'].strip()
            
            if 'plan' in data:
                plan = data['plan'].lower()
                if plan in [p.value for p in SchoolPlan]:
                    school.plan = SchoolPlan(plan)
                else:
                    return {
                        'success': False,
                        'message': f'Invalid plan. Must be one of: {", ".join([p.value for p in SchoolPlan])}'
                    }
            
            db.session.commit()
            
            logger.info(f"School updated successfully: {school.name} ({school.code})")
            
            return {
                'success': True,
                'message': 'School updated successfully',
                'data': school.to_dict()
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error updating school {school_id}: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to update school'
            }
    
    @staticmethod
    def delete_school(school_id):
        """Soft delete school"""
        try:
            school = School.query.filter(
                and_(School.id == school_id, School.is_active == True)
            ).first()
            
            if not school:
                return {
                    'success': False,
                    'message': 'School not found'
                }
            
            # Check if school has active users
            active_users_count = User.query.filter(
                and_(User.school_id == school_id, User.is_active == True)
            ).count()
            
            if active_users_count > 0:
                return {
                    'success': False,
                    'message': f'Cannot delete school with {active_users_count} active users. Please deactivate users first.'
                }
            
            # Soft delete
            school.is_active = False
            db.session.commit()
            
            logger.info(f"School soft deleted: {school.name} ({school.code})")
            
            return {
                'success': True,
                'message': 'School deleted successfully'
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error deleting school {school_id}: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to delete school'
            }
    
    @staticmethod
    def assign_school_admin(school_id, user_data):
        """Assign or create school admin for a school"""
        try:
            # Check if school exists and is active
            school = School.query.filter(
                and_(School.id == school_id, School.is_active == True)
            ).first()
            
            if not school:
                return {
                    'success': False,
                    'message': 'School not found'
                }
            
            # Check if user already exists
            existing_user = User.query.filter(
                and_(User.email == user_data['email'], User.is_active == True)
            ).first()
            
            if existing_user:
                # If user exists but is not assigned to this school
                if existing_user.school_id != school_id:
                    return {
                        'success': False,
                        'message': 'User with this email already exists in another school'
                    }
                
                # If user exists in this school, update role to school admin
                if existing_user.role != UserRole.SCHOOL_ADMIN:
                    existing_user.role = UserRole.SCHOOL_ADMIN
                    db.session.commit()
                    
                    logger.info(f"User role updated to school admin: {existing_user.email}")
                    
                    return {
                        'success': True,
                        'message': 'User role updated to school admin',
                        'data': existing_user.to_dict()
                    }
                else:
                    return {
                        'success': False,
                        'message': 'User is already a school admin for this school'
                    }
            
            # Create new school admin user
            # Add required fields that might be missing
            if 'username' not in user_data:
                # Generate username from email if not provided
                user_data['username'] = user_data['email'].split('@')[0]
            
            if 'password' not in user_data:
                # Generate a default password (should be changed on first login)
                user_data['password'] = 'TempPass@123'
            
            user_data['role'] = 'school_admin'  # Use string value as per your UserService
            user_data['school_id'] = school_id
            
            # Use your existing UserService.create_user method
            try:
                user = UserService.create_user(user_data)
                
                logger.info(f"School admin created and assigned to school {school.name}: {user_data['email']}")
                return {
                    'success': True,
                    'message': 'School admin created and assigned successfully',
                    'data': user.to_dict()
                }
                
            except ValueError as e:
                return {
                    'success': False,
                    'message': str(e)
                }
            except Exception as e:
                return {
                    'success': False,
                    'message': f'Failed to create school admin: {str(e)}'
                }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Error assigning school admin to school {school_id}: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to assign school admin'
            }
    
    @staticmethod
    def get_school_users(school_id, page=1, per_page=10, role=''):
        """Get users for a specific school"""
        try:
            # Check if school exists
            school = School.query.filter(
                and_(School.id == school_id, School.is_active == True)
            ).first()
            
            if not school:
                return {
                    'success': False,
                    'message': 'School not found'
                }
            
            query = User.query.filter(
                and_(User.school_id == school_id, User.is_active == True)
            )
            
            # Apply role filter
            if role and role in [r.value for r in UserRole]:
                query = query.filter(User.role == UserRole(role))
            
            # Get paginated results
            pagination = query.order_by(User.created_at.desc()).paginate(
                page=page, per_page=per_page, error_out=False
            )
            
            users = [user.to_dict() for user in pagination.items]
            
            return {
                'success': True,
                'data': {
                    'school': school.to_dict(),
                    'users': users,
                    'pagination': {
                        'page': pagination.page,
                        'pages': pagination.pages,
                        'per_page': pagination.per_page,
                        'total': pagination.total,
                        'has_next': pagination.has_next,
                        'has_prev': pagination.has_prev
                    }
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting users for school {school_id}: {str(e)}")
            return {
                'success': False,
                'message': 'Failed to retrieve school users'
            }