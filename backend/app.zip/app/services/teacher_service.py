from app.models.main.User import User, UserRole
from app.models.tenant import Student, Teacher, SchoolUsers, TeacherSubject
from app import db
from flask import jsonify
from app.utils.db_manager import switch_to_school_db
from app.utils.helpers import generate_student_id
from app.services.userRole_service import UserRolesService

class TeacherService:
    @staticmethod
    def create_teacher_user(data, skid):
        user = None  # Track user so we can delete if needed
        school_user_id = None # New variable to store the ID from the tenant DB
        try:
            # Create in main DB
            user = User(
                username=data['username'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                phone=data.get('phone'),
                role=UserRole(data['role']),
                skid=skid,
                school_id=data.get('school_id')
            )
            user.set_password(data['password'])
            user.save()

            # Insert into tenant DB
            with switch_to_school_db(skid) as tenant_session:
                school_user = SchoolUsers(
                    username=data['username'],
                    email=data['email'],
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    phone_number=data.get('phone'),
                    role_id = data.get('role_id'),
                    skid=skid,
                    is_active=True
                )
                school_user.set_password(data['password'])
                tenant_session.add(school_user)
                tenant_session.flush()
                
                # Get the ID of the school user before the session closes
                school_user_id = school_user.id

                # Create respective profile
                if user.role == UserRole.TEACHER:
                    profile = Teacher(
                        user_id=school_user_id,
                        employee_id=data.get('employee_id'),
                        designation=data.get('designation'),
                        date_of_joining=data.get('date_of_joining'),
                        qualifications=data.get('qualifications'),
                        salary=data.get('salary')
                    )
                else:
                    raise ValueError("Only teacher/student logic implemented. Add parent/staff if needed.")

                tenant_session.add(profile)
                tenant_session.commit()

            user.school_user_id = school_user_id
            db.session.commit()
            
            # Assign the role after creating the teacher on the basis of role_id
            role_data = {
                "user_id": school_user_id,
                "role_id": data.get("role_id"),
                "assigned_by": 1
            }
            UserRolesService.assign_role_to_user(role_data, skid)

            return user.to_dict()

        except Exception as e:
            db.session.rollback()
             # Rollback tenant session if open
            if 'tenant_session' in locals():
                tenant_session.rollback()
    
            # Delete user from main DB if already created
            if user and user.id:
                try:
                    db.session.delete(user)
                    db.session.commit()
                except Exception as delete_error:
                    db.session.rollback()
                    print(f"Failed to clean up user from main DB: {delete_error}")
    
            raise Exception(f"Failed to create school user: {str(e)}")
            
    @staticmethod
    def check_duplicate_user(data, skid):
        """
        Check if user already exists in both main DB and tenant DB
        Returns error message if duplicate found, None if no duplicates
        """
        try:
            # Check main DB first
            existing_main_user = User.query.filter(
                (User.username == data['username']) | (User.email == data['email'])
            ).filter(User.skid == skid).first()
            
            if existing_main_user:
                return "Teacher with this username or email already exists"
            
            # Check tenant DB
            with switch_to_school_db(skid) as tenant_session:
                existing_tenant_user = tenant_session.query(SchoolUsers).filter(
                    (SchoolUsers.username == data['username']) | (SchoolUsers.email == data['email'])
                ).first()
                
                if existing_tenant_user:
                    return "Teacher with this username or email already exists"
            
            # Check if employee ID already exists (if provided)
            if data.get('employee_id'):
                with switch_to_school_db(skid) as tenant_session:
                    existing_teacher = tenant_session.query(Teacher).filter(
                        Teacher.employee_id == data['employee_id']
                    ).first()
                    
                    if existing_teacher:
                        return "Employee ID already exists"
            
            return None  # No duplicates found
            
        except Exception as e:
            return f"Error checking for duplicates: {str(e)}"
            
    @staticmethod
    def get_teachers(skid):
        try:
                # Create class in tenant DB
                with switch_to_school_db(skid) as tenant_session:
                    teachers = (
                        tenant_session.query(SchoolUsers)
                        .join(Teacher, SchoolUsers.id == Teacher.user_id)
                        .all()
                    )
                    return [teacher.to_dict() for teacher in teachers]
        
        except Exception as e:
            raise Exception(f"Failed to get teachers: {str(e)}")
            
    @staticmethod
    def get_subject_ids_by_teacher(teacher_id, skid):
        """
        Returns list of subject IDs assigned to a teacher
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                subject_ids = (
                    tenant_session.query(TeacherSubject.subject_id)
                    .filter(TeacherSubject.teacher_id == teacher_id)
                    .all()
                )
                return [sid[0] for sid in subject_ids]  # Convert list of tuples to list of IDs
        except Exception as e:
            raise Exception(f"Failed to fetch teacher subjects: {str(e)}")
