from app.models.main.User import User, UserRole
from app.models.main.School import School
from app.models.tenant import Student, Teacher, SchoolUsers, SchoolAdmin
from app import db
from sqlalchemy.exc import IntegrityError
from flask import jsonify
from app.utils.db_manager import switch_to_school_db
from app.utils.helpers import generate_student_id

class UserService:

    @staticmethod
    def create_school_admin(data):
        try:
            required_fields = ['username', 'email', 'password', 'first_name', 'last_name', 'skid', 'school_id']
            for field in required_fields:
                if not data.get(field):
                    raise ValueError(f"Missing required field: {field}")
            
            skid = data['skid']
            
            # Validate uniqueness
            if User.get_by_username(data['username']):
                raise ValueError("Username already exists")
            if User.get_by_email(data['email']):
                raise ValueError("Email already exists")

            school = School.query.get(data['school_id'])
            if not school:
                raise ValueError("Invalid school_id")

            # Create in main users table
            user = User(
                username=data['username'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                phone=data.get('phone'),
                role=UserRole.SCHOOL_ADMIN,
                skid=skid,
                school_id=school.id
            )
            user.set_password(data['password'])
            user.save()

            # Set this user as admin of the school
            school.school_admin_id = user.id
            db.session.commit()

            # Create in tenant DB: school_users and school_admins
            with switch_to_school_db(skid) as session:
                school_user = SchoolUsers(
                    username=data['username'],
                    email=data['email'],
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    skid=skid,
                    is_active=True
                )
                school_user.set_password(data['password'])
                session.add(school_user)
                session.flush()

                school_admin_profile = SchoolAdmin(
                    user_id=school_user.id,
                    designation=str(data.get('designation', UserRole.SCHOOL_ADMIN))
                )
                session.add(school_admin_profile)
                session.commit()

                # Link back school_user_id to main DB
                user.school_user_id = school_user.id
                db.session.commit()

            return user

        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to create school admin: {str(e)}")

    
    @staticmethod
    def create_school_user(data):
        try:
            required_fields = ['username', 'email', 'password', 'first_name', 'last_name', 'role', 'skid', 'school_id']
            for field in required_fields:
                if not data.get(field):
                    raise ValueError(f"Missing required field: {field}")
            
            skid = data['skid']
            
            if data['role'] not in ['TEACHER', 'STUDENT', 'PARENT', 'STAFF']:
                raise ValueError("Invalid school user role")

            school = School.query.get(data['school_id'])
            if not school:
                raise ValueError("Invalid school_id")

            # Create in main DB
            user = User(
                username=data['username'],
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                phone=data.get('phone'),
                role=UserRole(data['role']),
                skid=skid,
                school_id=school.id
            )
            user.set_password(data['password'])
            user.save()

            # Insert into tenant DB
            with switch_to_school_db(skid) as tenant_session:
                school_user = SchoolUsers(
                    username=data['username'],
                    email=data['email'],
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    phone_number=data.get('phone'),
                    skid=skid,
                    is_active=True
                )
                school_user.set_password(data['password'])
                tenant_session.add(school_user)
                tenant_session.flush()

                # Create respective profile
                if user.role == UserRole.TEACHER:
                    profile = Teacher(
                        user_id=school_user.id,
                        employee_id=data.get('employee_id'),
                        designation=data.get('designation'),
                        date_of_joining=data.get('date_of_joining'),
                        qualifications=data.get('qualifications'),
                        salary=data.get('salary')
                    )
                elif user.role == UserRole.STUDENT:
                    profile = Student(
                        user_id=school_user.id,
                        student_id=data.get('student_id'),
                        admission_date=data.get('admission_date'),
                        class_id=data.get('class_id'),
                        section_id=data.get('section_id')
                    )
                else:
                    raise ValueError("Only teacher/student logic implemented. Add parent/staff if needed.")

                tenant_session.add(profile)
                tenant_session.commit()

                user.school_user_id = school_user.id
                db.session.commit()

            return user

        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to create school user: {str(e)}")

    
    @staticmethod
    def update_user(user_id, user_data):
        """
        Update existing user
        """
        try:
            user = User.get_by_id(user_id)
            if not user:
                raise ValueError("User not found")
            
            # Update fields if provided
            updatable_fields = ['email', 'first_name', 'last_name', 'phone', 'role', 'school_id']
            
            for field in updatable_fields:
                if field in user_data:
                    if field == 'email':
                        # Check if email is already taken by another user
                        existing_user = User.get_by_email(user_data['email'])
                        if existing_user and existing_user.id != user.id:
                            raise ValueError("Email already exists")
                    
                    elif field == 'role':
                        # Validate role
                        try:
                            role = UserRole(user_data['role'])
                            setattr(user, field, role)
                        except ValueError:
                            raise ValueError("Invalid role")
                        continue
                    
                    elif field == 'school_id':
                        # Validate school
                        if user_data['school_id']:
                            school = School.get_by_id(user_data['school_id'])
                            if not school:
                                raise ValueError("Invalid school_id")
                    
                    setattr(user, field, user_data[field])
            
            # Update password if provided
            if 'password' in user_data and user_data['password']:
                user.set_password(user_data['password'])
            
            user.save()
            return user
            
        except IntegrityError as e:
            db.session.rollback()
            raise ValueError("Email already exists")
        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to update user: {str(e)}")
    
    @staticmethod
    def deactivate_user(user_id):
        """
        Deactivate user (soft delete)
        """
        try:
            user = User.get_by_id(user_id)
            if not user:
                raise ValueError("User not found")
            
            user.delete()  # This sets is_active to False
            return user
            
        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to deactivate user: {str(e)}")
    
    @staticmethod
    def activate_user(user_id):
        """
        Activate user
        """
        try:
            # Get user even if inactive
            user = User.query.filter_by(id=user_id).first()
            if not user:
                raise ValueError("User not found")
            
            user.activate()
            return user
            
        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to activate user: {str(e)}")
    
    @staticmethod
    def get_users_by_school(skid):
        """
        Get all users for a specific school
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                users = tenant_session.query(SchoolUsers).filter(SchoolUsers.is_active == True).all()
                return [user.to_dict() for user in users]
        except Exception as e:
            raise Exception(f"Failed to get users: {str(e)}")

    
    @staticmethod
    def get_user_by_id(user_id, include_inactive=False):
        """
        Get user by ID
        """
        try:
            if include_inactive:
                user = User.query.filter_by(id=user_id).first()
            else:
                user = User.get_by_id(user_id)
            
            return user
            
        except Exception as e:
            raise Exception(f"Failed to get user: {str(e)}")
    
    @staticmethod
    def change_password(user_id, old_password, new_password):
        """
        Change user password
        """
        try:
            user = User.get_by_id(user_id)
            if not user:
                raise ValueError("User not found")
            
            if not user.check_password(old_password):
                raise ValueError("Invalid current password")
            
            user.set_password(new_password)
            user.save()
            
            return user
            
        except Exception as e:
            db.session.rollback()
            raise Exception(f"Failed to change password: {str(e)}")