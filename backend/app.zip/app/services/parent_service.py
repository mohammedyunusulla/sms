from app.models.main.User import User, UserRole
from app.models.main.School import School
from app.models.tenant import SchoolUsers, Parent, StudentParent, Student
from app import db
from sqlalchemy.exc import IntegrityError
from flask import jsonify
from app.utils.db_manager import switch_to_school_db
from app.services.userRole_service import UserRolesService
from datetime import datetime, date

class ParentService:
    
    @staticmethod
    def create_parent_user(data, skid):
        """
        Create a new parent user in both main and tenant databases
        """
        user = None  # Track user so we can delete if needed
        school_user_id = None  # New variable to store the ID from the tenant DB
        
        try:
            # Get school information
            school = School.query.filter_by(skid=skid).first()
            if not school:
                raise ValueError("School not found")
            
            # Create user in main DB
            user = User(
                username=data.get('username', data['email']),
                email=data['email'],
                first_name=data['first_name'],
                last_name=data['last_name'],
                phone=data.get('phone'),
                role=UserRole.PARENT,  # Assuming you have PARENT role
                skid=skid,
                school_id=school.id
            )
            user.set_password(data['password'])
            user.save()

            # Insert into tenant DB
            with switch_to_school_db(skid) as tenant_session:
                # Check if a user with the same username or email already exists in the tenant DB
                existing_user = tenant_session.query(SchoolUsers).filter(
                    (SchoolUsers.username == user.username) | (SchoolUsers.email == data['email'])
                ).first()
                if existing_user:
                    # If an existing user is found, roll back the main DB user creation and raise an error.
                    db.session.rollback()
                    raise ValueError("User with this username or email already exists in this school.")
                
                # Create school user
                school_user = SchoolUsers(
                    username=user.username,
                    email=data['email'],
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    phone=data.get('phone'),
                    role_id=data.get('role_id', 5),  # Assuming 5 is parent role
                    skid=skid,
                    is_active=True
                )
                school_user.set_password(data['password'])
                tenant_session.add(school_user)
                tenant_session.flush()
                
                # Get the ID of the school user before the session closes
                school_user_id = school_user.id

                # Create parent profile
                parent_profile = Parent(
                    user_id=school_user_id,
                    relation_type=data.get('relation_type', ''),
                    father_full_name=data.get('father_full_name', ''),
                    father_phone=data.get('father_phone', ''),
                    father_occupation=data.get('father_occupation', ''),
                    father_qualification=data.get('father_qualification', ''),
                    mother_full_name=data.get('mother_full_name', ''),
                    mother_phone=data.get('mother_phone', ''),
                    mother_occupation=data.get('mother_occupation', ''),
                    mother_qualification=data.get('mother_qualification', ''),
                    address=data.get('address', ''),
                    city=data.get('city', ''),
                    state=data.get('state', ''),
                    postal_code=data.get('postal_code', '')
                )
                tenant_session.add(parent_profile)
                tenant_session.commit()

            # Update main user with school_user_id
            user.school_user_id = school_user_id
            db.session.commit()
            
            # Assign the role after creating the parent
            role_data = {
                "user_id": school_user_id,
                "role_id": data.get("role_id", 5),  # Parent role
                "assigned_by": 1
            }
            UserRolesService.assign_role_to_user(role_data, skid)

            return user.to_dict()

        except Exception as e:
            db.session.rollback()

            # Rollback tenant session if open
            if 'tenant_session' in locals():
                tenant_session.rollback()

            # Delete user from main DB if already created
            if user and user.id:
                try:
                    db.session.delete(user)
                    db.session.commit()
                except Exception as delete_error:
                    db.session.rollback()
                    print(f"Failed to clean up user from main DB: {delete_error}")

            raise Exception(f"Failed to create parent user: {str(e)}")

    @staticmethod
    def get_all_parents(skid, page=1, per_page=50, search=''):
        """
        Get all parents for a school with pagination and search
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                query = tenant_session.query(Parent).join(SchoolUsers).filter(
                    SchoolUsers.role_id == 5,  # Parent role
                    SchoolUsers.is_active == True
                )
                
                # Add search filter
                if search:
                    search_filter = f"%{search}%"
                    query = query.filter(
                        (Parent.first_name.ilike(search_filter)) |
                        (Parent.last_name.ilike(search_filter)) |
                        (Parent.email.ilike(search_filter)) |
                        (Parent.phone_number.ilike(search_filter))
                    )
                
                # Apply pagination
                parents = query.offset((page - 1) * per_page).limit(per_page).all()
                
                return [
                    {
                        "id": parent.user_id,
                        "relation_type": parent.relation_type,
                        "father_full_name": parent.father_full_name,
                        "father_phone": parent.father_phone,
                        "mother_full_name": parent.mother_full_name,
                        "mother_phone": parent.mother_phone,
                        "address": parent.address,
                        "city": parent.city,
                        "state": parent.state,
                        "postal_code": parent.postal_code,
                    }
                    for parent in parents
                ]
        except Exception as e:
            raise Exception(f"Failed to fetch parents: {str(e)}")

    @staticmethod
    def get_parent_by_id(parent_id, skid):
        """
        Get parent details by ID
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                parent = tenant_session.query(Parent).filter(
                    Parent.user_id == parent_id
                ).first()
                
                if not parent:
                    raise ValueError("Parent not found")
                
                return {
                    "id": parent.user_id,
                    "first_name": parent.first_name,
                    "last_name": parent.last_name,
                    "email": parent.email,
                    "phone": parent.phone_number,
                    "occupation": parent.occupation,
                    "education_level": parent.education_level
                }
        except Exception as e:
            raise Exception(f"Failed to fetch parent: {str(e)}")

    @staticmethod
    def link_student_to_parent(student_user_id, parent_user_id, relation_type, skid):
        """
        Link existing student to existing parent
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                # Check if relationship already exists
                existing_link = tenant_session.query(StudentParent).filter(
                    StudentParent.student_user_id == student_user_id,
                    StudentParent.parent_user_id == parent_user_id
                ).first()
                
                if existing_link:
                    raise ValueError("Student is already linked to this parent")
                
                # Verify student and parent exist
                student = tenant_session.query(Student).filter(
                    Student.user_id == student_user_id
                ).first()
                parent = tenant_session.query(Parent).filter(
                    Parent.user_id == parent_user_id
                ).first()
                
                if not student:
                    raise ValueError("Student not found")
                if not parent:
                    raise ValueError("Parent not found")
                
                # Create new relationship
                student_parent = StudentParent(
                    student_user_id=student_user_id,
                    parent_user_id=parent_user_id,
                    relation_type=relation_type
                )
                tenant_session.add(student_parent)
                tenant_session.commit()
                
                return {"success": True, "message": "Student linked to parent successfully"}
        except Exception as e:
            raise Exception(f"Failed to link student to parent: {str(e)}")

    @staticmethod
    def get_student_parents(student_user_id, skid):
        """
        Get all parents linked to a student
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                parents = tenant_session.query(Parent, StudentParent.relation_type).join(
                    StudentParent, Parent.user_id == StudentParent.parent_user_id
                ).filter(
                    StudentParent.student_user_id == student_user_id
                ).all()
                
                return [
                    {
                        "id": parent.user_id,
                        "name": f"{parent.first_name} {parent.last_name}",
                        "first_name": parent.first_name,
                        "last_name": parent.last_name,
                        "email": parent.email,
                        "phone": parent.phone_number,
                        "relation_type": relation_type,
                        "occupation": parent.occupation,
                        "education_level": parent.education_level
                    }
                    for parent, relation_type in parents
                ]
        except Exception as e:
            raise Exception(f"Failed to fetch student parents: {str(e)}")

    @staticmethod
    def unlink_student_parent(student_user_id, parent_user_id, skid):
        """
        Unlink student from parent
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                student_parent = tenant_session.query(StudentParent).filter(
                    StudentParent.student_user_id == student_user_id,
                    StudentParent.parent_user_id == parent_user_id
                ).first()
                
                if not student_parent:
                    raise ValueError("Student-parent relationship not found")
                
                tenant_session.delete(student_parent)
                tenant_session.commit()
                
                return {"success": True, "message": "Student unlinked from parent successfully"}
        except Exception as e:
            raise Exception(f"Failed to unlink student from parent: {str(e)}")

    @staticmethod
    def update_parent(parent_id, data, skid):
        """
        Update parent information
        """
        try:
            with switch_to_school_db(skid) as tenant_session:
                parent = tenant_session.query(Parent).filter(
                    Parent.user_id == parent_id
                ).first()
                
                if not parent:
                    raise ValueError("Parent not found")
                
                # Update parent profile
                parent.first_name = data.get('first_name', parent.first_name)
                parent.last_name = data.get('last_name', parent.last_name)
                parent.email = data.get('email', parent.email)
                parent.phone_number = data.get('phone', parent.phone_number)
                parent.occupation = data.get('occupation', parent.occupation)
                parent.education_level = data.get('education_level', parent.education_level)
                
                # Update school user
                school_user = tenant_session.query(SchoolUsers).filter(
                    SchoolUsers.id == parent_id
                ).first()
                
                if school_user:
                    school_user.first_name = data.get('first_name', school_user.first_name)
                    school_user.last_name = data.get('last_name', school_user.last_name)
                    school_user.email = data.get('email', school_user.email)
                    school_user.phone_number = data.get('phone', school_user.phone_number)
                
                tenant_session.commit()
                
                return parent
        except Exception as e:
            raise Exception(f"Failed to update parent: {str(e)}")