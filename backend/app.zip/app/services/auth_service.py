from flask import request
from flask_jwt_extended import create_access_token, create_refresh_token
from app.models.main.User import User
from app.models.main.UserSession import UserSession
from app.models.tenant.Roles import Role
from app.models.tenant.UserRoles import UserRoles
from app.decorators.logging import log_login_attempt, log_logout
from datetime import datetime
from app.utils.db_manager import switch_to_school_db
import uuid

class AuthService:
    
    @staticmethod
    def authenticate_user(identifier, password):
        """
        login:
        Authenticate user with username/password
        Returns user object if successful, None otherwise
        """
        try:
            # Find user by username or email
            user = User.get_by_username(identifier)
            if not user:
                user = User.get_by_email(identifier)
            if not user:
                log_login_attempt(success=False, error_message="User not found")
                return None
            
            if not user.is_active:
                log_login_attempt(success=False, user=user, error_message="Account deactivated")
                return None
            
            if not user.check_password(password):
                log_login_attempt(success=False, user=user, error_message="Invalid password")
                return None
            
            log_login_attempt(success=True, user=user)
            return user
            
        except Exception as e:
            log_login_attempt(success=False, error_message=f"Authentication error: {str(e)}")
            return None
    
    @staticmethod
    def create_user_session(user):
        """
        Create user session and JWT tokens
        Returns dict with tokens and user info
        """
        try:
            # Update user's last login
            user.update_last_login()
    
            # Create session record
            session_token = str(uuid.uuid4())
            ip_address = request.environ.get('HTTP_X_FORWARDED_FOR', request.environ.get('REMOTE_ADDR'))
            user_agent = request.headers.get('User-Agent', '')
    
            session = UserSession(
                user_id=user.id,
                session_token=session_token,
                ip_address=ip_address,
                user_agent=user_agent
            )
            session.save()
    
            # Fetch role data from the tenant (school) DB
            role_data = None
            if user.school_id:
                with switch_to_school_db(user.skid) as school_session:
                    user_role = (
                        school_session.query(Role)
                        .join(UserRoles, UserRoles.role_id == Role.id)
                        .filter(UserRoles.user_id == user.school_user_id)
                        .first()
                    )
    
                    if user_role:
                        role_data = {
                            "id": user_role.id,
                            "role_name": user_role.role_name,
                            "role_code": user_role.role_code,
                            "school_id": user_role.school_id,
                            "is_active": user_role.is_active,
                            "is_system_role": user_role.is_system_role,
                            "permissions": user_role.permissions
                        }
    
            # Create JWT tokens
            access_token = create_access_token(
                identity=str(user.id),
                # additional_claims={
                #     'role': role_data["role_code"] if role_data else None,
                #     'school_id': user.school_id,
                #     'session_token': session_token
                # }
            )
    
            refresh_token = create_refresh_token(identity=user.id)
    
            return {
                'access_token': access_token,
                'refresh_token': refresh_token,
                'user': {
                    **user.to_dict(),
                    'role_obj': role_data
                },
                'session_id': session.id
            }
    
        except Exception as e:
            raise Exception(f"Failed to create session: {str(e)}")
    
    @staticmethod
    def logout_user(user, session_token=None):
        """
        Logout user and invalidate session
        """ 
        try:
            # Find and logout session
            if session_token:
                session = UserSession.get_active_session(session_token)
                if session and session.user_id == user.id:
                    session.logout()
            else:
                # Logout all active sessions for user
                active_sessions = UserSession.get_user_sessions(user.id, active_only=True)
                for session in active_sessions:
                    session.logout()
            
            log_logout(user)
            return True
            
        except Exception as e:
            raise Exception(f"Failed to logout: {str(e)}")
    
    @staticmethod
    def refresh_token(user_id):
        """
        Create new access token from refresh token
        """
        try:
            user = User.get_by_id(user_id)
            if not user or not user.is_active:
                return None
            
            access_token = create_access_token(
                identity=str(user.id),
                additional_claims={
                    'role': user.role.value,
                    'school_id': user.school_id
                }
            )
            
            return {
                'access_token': access_token,
                'user': user.to_dict()
            }
            
        except Exception as e:
            raise Exception(f"Failed to refresh token: {str(e)}")