from app.models.base import BaseModelTenant, BaseModelTenantMixin
from sqlalchemy import Column, String, Integer, Date, ForeignKey, func
from sqlalchemy.orm import relationship

class StudentEnrollment(BaseModelTenant, BaseModelTenantMixin):
    __tablename__ = 'student_enrollments'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(Integer, ForeignKey('students.user_id'))
    class_id = Column(Integer, ForeignKey('classes.id'))
    section_id = Column(Integer, ForeignKey('sections.id'))
    enrollment_date = Column(Date, default=func.current_date())
    status = Column(String(20), default='active')
    
    # Relationships
    student = relationship("Student", backref="enrollments")
    class_obj = relationship("Class", back_populates="enrollments")
    section_obj = relationship("Section", back_populates="enrollments")
    
    def __repr__(self):
        return f"<StudentEnrollment StudentUserID:{self.student_user_id} ClassID:{self.class_id} Status:{self.status}>"