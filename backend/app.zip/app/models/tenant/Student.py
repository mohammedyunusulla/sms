from app.models.base import BaseModelTenant, BaseModelTenantMixin
from sqlalchemy import Column, String, DateTime, Integer, Date, func, ForeignKey
from sqlalchemy.orm import relationship

class Student(BaseModelTenant, BaseModelTenantMixin):
    __tablename__ = 'students'
    
    user_id = Column(Integer, ForeignKey('school_users.id'), primary_key=True)
    roll_no = Column(String(50), nullable=True) # Unique within the school, e.g., roll number
    admission_date = Column(Date)
    class_id = Column(Integer, ForeignKey('classes.id'), nullable=True) 
    section_id = Column(Integer, ForeignKey('sections.id'), nullable=True) # Assuming a `sections` table will be created
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    user = relationship("SchoolUsers", back_populates="student")
    # Relationships to actual Class and Section objects (defined in school_data.py)
    # class_obj = relationship("Class", back_populates="students_in_class") # Example, needs to be defined in Class
    section_obj = relationship("Section", back_populates="students_in_section") # Example, needs to be defined in Section
    attendance_records = relationship("Attendance", back_populates="student_profile")
    
    parent_links = relationship(
        "StudentParent", 
        foreign_keys="[StudentParent.student_user_id]", 
        back_populates="student"
    )