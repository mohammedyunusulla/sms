# app/models/school_users.py
from app.models.base import BaseModelTenant, BaseModelTenantMixin
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text, Date
from sqlalchemy.orm import relationship
from werkzeug.security import generate_password_hash, check_password_hash
from .UserRoles import UserRoles

# --- User Table (Tenant DB - consolidated users for a specific school) ---
class SchoolUsers(BaseModelTenant, BaseModelTenantMixin): 
    __tablename__ = 'school_users'
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False) # Making email nullable=False is common for school users
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    date_of_birth = Column(Date)
    gender = Column(String(20)) # Use the defined GenderEnum
    address = Column(Text)
    phone = Column(String(20))
    role_id = Column(Integer, ForeignKey('roles.id'))
    skid = Column(String(50), nullable=False)
    is_active = Column(Boolean, default=True)
    # created_at and updated_at are inherited from BaseModelTenant

    # Relationships to profile tables (one-to-one with cascade for deletion)
    school_admin = relationship("SchoolAdmin", uselist=False, back_populates="user", cascade="all, delete-orphan")
    teacher = relationship("Teacher", uselist=False, back_populates="user", cascade="all, delete-orphan")
    student = relationship("Student", uselist=False, back_populates="user", cascade="all, delete-orphan")
    staff = relationship("Staff", uselist=False, back_populates="user", cascade="all, delete-orphan")
    parent = relationship("Parent", uselist=False, back_populates="user", cascade="all, delete-orphan")
    role_obj = relationship("Role", back_populates="users")
    roles = relationship("UserRoles", back_populates="user", foreign_keys=[UserRoles.user_id])


    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password matches hash"""
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        role_name = self.role_obj.role_name if self.role_obj else "No Role"
        return f"<SchoolUser {self.username} Role: {role_name}>"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def to_dict(self, exclude_fields=None):
        if exclude_fields is None:
            exclude_fields = ['password_hash']
        data = super().to_dict(exclude_fields)
        data['full_name'] = self.full_name
        data['role'] = self.roles[0].role.to_dict() if self.roles else None
        
        # Add profile data if exists
        if self.school_admin:
            data['profile'] = self.school_admin.to_dict()
        elif self.teacher:
            data['profile'] = self.teacher.to_dict()
        elif self.student:
            data['profile'] = self.student.to_dict()
        elif self.staff:
            data['profile'] = self.staff.to_dict()
        elif self.parent:
            data['profile'] = self.parent.to_dict()
        
        return data
