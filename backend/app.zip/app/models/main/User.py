from app.models.base import BaseModel
from sqlalchemy import Column, String, Integer, DateTime, ForeignKey, Enum
from sqlalchemy.orm import relationship
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import enum

class UserRole(enum.Enum):
    SUPER_ADMIN = "SUPER_ADMIN"
    SCHOOL_ADMIN = "SCHOOL_ADMIN"
    PRINCIPAL = "PRINCIPAL"
    TEACHER = "TEACHER"
    STUDENT = "STUDENT"
    PARENT = "PARENT"

class User(BaseModel):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(80), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    phone = Column(String(20))
    role = Column(Enum(UserRole), nullable=False)
    last_login = Column(DateTime)
    skid = Column(String(50))
    school_id = Column(Integer, ForeignKey('schools.id'), nullable=True)  # Null for super admin
    school_user_id = Column(Integer, nullable=True)  # Links to student/teacher ID in school DB and Null for super admin
    
    # Relationships
    school = relationship("School", back_populates="users")
    sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if password matches hash"""
        return check_password_hash(self.password_hash, password)
    
    def update_last_login(self):
        """Update last login timestamp"""
        self.last_login = datetime.utcnow()
        return self.save()
    
    def __repr__(self):
        return f'<User {self.username}>'
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    @classmethod
    def get_by_username(cls, username):
        """Get user by username"""
        return cls.query.filter_by(username=username, is_active=True).first()
    
    @classmethod
    def get_by_email(cls, email):
        """Get user by email"""
        return cls.query.filter_by(email=email, is_active=True).first()
    
    @classmethod
    def get_by_school(cls, school_id):
        """Get all users by school"""
        return cls.query.filter_by(school_id=school_id, is_active=True).all()
    
    def to_dict(self, exclude_fields=None):
        """Convert user to dictionary, excluding sensitive fields"""
        if exclude_fields is None:
            exclude_fields = ['password_hash']
        else:
            exclude_fields.append('password_hash')
        
        data = super().to_dict(exclude_fields)
        data['full_name'] = self.full_name
        
        if self.school:
            data['school_name'] = self.school.name
            data['school_code'] = self.school.code
            data['skid'] = self.school.skid
        return data