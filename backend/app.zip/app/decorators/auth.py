from functools import wraps
from flask import request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
import jwt
from app.models.main.User import User, UserRole   
from functools import wraps

def login_required(allowed_roles=None):
    """
    Simple decorator to require login and optionally check roles
    """
    def decorator(f):
        @wraps(f)
        @jwt_required()
        def decorated_function(*args, **kwargs):
            try:
                from flask import g
                # Get current user ID from JWT
                current_user_id = get_jwt_identity()
                print("current user id---->>", current_user_id)
                if not current_user_id:
                    return jsonify({'message': 'Invalid token'}), 401
                
                # Get user from database
                from app.models.main.User import User
                user = User.get_by_id(current_user_id)
                print("user---->>", user.role.value)
                
                if not user:
                    return jsonify({'message': 'User not found'}), 404
                
                if not user.is_active:
                    return jsonify({'message': 'User account is deactivated'}), 403
                
                # Check roles if specified
                if allowed_roles:
                    user_role = user.role.value if hasattr(user.role, 'value') else user.role
                    if user_role not in allowed_roles:
                        return jsonify({'message': 'Insufficient permissions'}), 403
                
                # Add user to request context
                request.current_user = user
                g.current_user = user
                
                return f(*args, **kwargs)
            
            except Exception as e:
                return jsonify({'message': f'Authentication failed: {str(e)}'}), 401
        
        return decorated_function
    return decorator

def super_admin_required(f):
    """Decorator to require super admin role"""
    return login_required(['super_admin'])(f)

def school_admin_required(f):
    """Decorator to require school admin or higher role"""
    return login_required(['super_admin', 'school_admin', 'principal'])(f)

def teacher_required(f):
    """Decorator to require teacher or higher role"""
    return login_required(['super_admin', 'school_admin', 'principal', 'teacher'])(f)

def same_school_required(f):
    """
    Decorator to ensure user can only access data from their own school
    (Super admins can access any school)
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = getattr(request, 'current_user', None)
        if not user:
            return jsonify({'message': 'User not authenticated'}), 401
        
        # Super admins can access any school
        if user.role == UserRole.SUPER_ADMIN:
            return f(*args, **kwargs)
        
        # For other users, add school_id filter to kwargs if not present
        if 'school_id' not in kwargs and user.school_id:
            kwargs['school_id'] = user.school_id
        
        return f(*args, **kwargs)
    
    return decorated_function