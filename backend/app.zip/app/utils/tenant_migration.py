# utils/tenant_migration.py

import os
from dotenv import load_dotenv
from sqlalchemy import create_engine, text
import subprocess

load_dotenv()

MAIN_DB_URL = os.getenv("SUPER_ADMIN_DATABASE_URL")


def get_all_schools():
    engine = create_engine(MAIN_DB_URL)
    with engine.connect() as conn:
        result = conn.execute(text("SELECT skid FROM schools"))
        return [row[0] for row in result]


def upgrade_all_tenants():
    school_ids = get_all_schools()
    for skid in school_ids:
        db_name = f"skool_{skid}"
        db_url = f"postgresql://postgres:password@localhost/{db_name}"

        print(f"⚙️  Running migration for: {db_name}")
        env = os.environ.copy()
        env["TENANT_DB_URL"] = db_url

        subprocess.run([
            "alembic",
            "-c", "migrations_tenant/alembic_tenant.ini",
            "upgrade", "head"
        ], env=env)

# ✅ Add this block
if __name__ == "__main__":
    upgrade_all_tenants()
