from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def get_tenant_engine(db_name):
    return create_engine(f'postgresql://postgres:postgres@localhost/{db_name}')

def get_tenant_session(db_name):
    engine = get_tenant_engine(db_name)
    Session = sessionmaker(bind=engine)
    return Session()
